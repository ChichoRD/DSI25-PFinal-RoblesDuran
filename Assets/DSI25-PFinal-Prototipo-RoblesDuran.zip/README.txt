Descripción del proyecto final:

Un pequeño juego de exploración con temática medieval-fantasía basado totalmente en menús de UI Toolkit.
Eres un explorador y cada día puedes viajar a hasta tres localizaciones conexas.
Cada vez que descubras un nuevo lugar de interés podrás ponerle un icono personalizado y tomar notas sobre el lugar.

- Las notas y iconos que elijas se guardarán cada día.
- Las localizaciones descubiertas serán persistentes entre partidas. Almacenadas en JSON.
- Los lugares tendrán pequeñas historias que contarte cada vez diferentes, escogidas desde un JSON.
- Al hacer "hover" sobre una localización aparecerá un elemento con toda esta información que seguirá al ratón.
- Algunos días aparecerá un menú con información sobre tu aventura.
- Hay un "scroll view" de tus los lugares de tus viajes.